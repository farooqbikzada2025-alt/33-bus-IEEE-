clear
clc
A=[];
b=[];
Aeq=[];
beq=[];
lb=[2;0];
ub=[33;10];
options = gaoptimset('PlotFcns',{@gaplotbestf,@gaplotstopping},'populationsize',200);
[x,fval]=ga(@loss33,2,A,b,Aeq,beq,lb,ub,[],options);
disp(sprintf('-----------*****************-------------'));
disp(sprintf('Best bus for DG allocation is bus no. %d with %d pu power',floor(x(1)),x(2)));
disp(sprintf('Total loss of system: %d kw',fval));
disp(sprintf('-----------*****************-------------'));

                   