function myfun=myfun(x)
myfun=x^3-2*x+1;
end