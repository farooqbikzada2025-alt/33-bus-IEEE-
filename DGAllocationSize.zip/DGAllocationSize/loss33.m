function loss33=loss33(x)
data=[
 1                         2                     100+60i                0.0922+0.047i 
 2                         3                      90+40i                 0.493+0.251i 
 3                         4                     120+80i                0.3661+0.1864i
 4                         5                      60+30i                0.3811+0.1941i
 5                         6                      60+20i                 0.819+0.707i 
 6                         7                     200+100i               0.1872+0.6188i
 7                         8                     200+100i               1.7117+1.2357i
 8                         9                      60+20i                1.0299+0.74i  
 9                        10                      60+20i                 1.044+0.74i  
10                        11                      45+30i                0.1967+0.0651i
11                        12                      60+35i                0.3744+0.1237i
12                        13                      60+35i                 1.468+1.1549i
13                        14                     120+80i                0.5416+0.7129i
14                        15                      60+10i                0.5909+0.526i 
15                        16                      60+20i                0.7462+0.5449i
16                        17                      60+20i                1.2889+1.721i 
17                        18                      90+40i                 0.732+0.5739i
 2                        19                      90+40i                 0.164+0.1564i
19                        20                      90+40i                1.5042+1.3555i
20                        21                      90+40i                0.4095+0.4784i
21                        22                      90+40i                0.7089+0.9373i
 3                        23                      90+50i                0.4512+0.3084i
23                        24                     420+200i                0.898+0.7091i
24                        25                     420+200i               0.8959+0.701i 
 6                        26                      60+25i                0.2031+0.1034i
26                        27                      60+25i                0.2842+0.1447i
27                        28                      60+20i                1.0589+0.9338i
28                        29                     120+70i                0.8043+0.7006i
29                        30                     200+600i               0.5074+0.2585i
30                        31                     150+70i                0.9745+0.9629i
31                        32                     210+100i               0.3105+0.3619i
32                        33                      60+40i                0.3411+0.5302i];
vbus=ones(1,33);
iline=zeros(1,32);
ibus=zeros(1,33);
s1=data(:,3)/1000;
data(:,4)=data(:,4)/(12.66^2);
loss=0;
err=1;
ittr=0;
s=s1*1;
db=floor(x(1));
s(db-1)=s(db-1)-x(2);
while err>0.00001
vbust=vbus;
for i=2:33
    ibus(i)=conj(s(i-1)/vbus(i));
end
iline(24)=ibus(25);
iline(32)=ibus(33);
iline(17)=ibus(18);
iline(21)=ibus(22);
%%%%%%%%%%%%%%%%%%%%%%%%
for i=16:-1:6
    iline(i)=iline(i+1)+ibus(i+1);
end
for i=31:-1:26
    iline(i)=iline(i+1)+ibus(i+1);
end
for i=20:-1:19
    iline(i)=iline(i+1)+ibus(i+1);
end
iline(23)=iline(24)+ibus(24);
iline(5)=iline(6)+ibus(6)+iline(26)+ibus(26);
iline(4)=iline(5)+ibus(5);
iline(3)=iline(4)+ibus(4);
iline(2)=iline(3)+ibus(3)+iline(23)+ibus(23);
iline(1)=iline(2)+ibus(2)+iline(19)+ibus(19);
for i=2:18
    vbus(i)=vbus(i-1)-data(i-1,4)*iline(i-1);
end
vbus(19)=vbus(2)-data(18,4)*(iline(19)+ibus(19));
for i=20:22
    vbus(i)=vbus(i-1)-data(i-1,4)*iline(i-1);
end
vbus(23)=vbus(2)-data(22,4)*(iline(23)+ibus(23));
for i=24:25
    vbus(i)=vbus(i-1)-data(i-1,4)*iline(i-1);
end
vbus(26)=vbus(6)-data(25,4)*(iline(26)+ibus(26));
for i=27:33
    vbus(i)=vbus(i-1)-data(i-1,4)*iline(i-1);
end
err=max(max(abs(vbus)-abs(vbust)),abs(min(abs(vbus)-abs(vbust))));
ittr=ittr+1;
end
%
loss=loss+data(22,4)*(iline(23)+ibus(23))^2;
loss=loss+data(25,4)*(iline(26)+ibus(26))^2;
loss=loss+data(18,4)*(iline(19)+ibus(19))^2;
for i=[(1:17),(19:21),(23:24),(26:32)]
    loss=loss+data(i,4)*(abs(iline(i)))^2;
end
%********************** end of total loss calculation *******
loss33=real(loss*1000);
for i=1:33
    if (abs(vbus(i))-1)^2>0.0025 
        loss33=10^6;
    end
end
end