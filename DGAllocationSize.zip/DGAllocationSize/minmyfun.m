clc
clear
[x,fval]=ga(@myfun,1,[],[],[],[],[0],[4])